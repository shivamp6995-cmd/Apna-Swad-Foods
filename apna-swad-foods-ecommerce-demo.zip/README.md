# Apna Swad Foods — E-commerce Demo

Open `index.html` in a browser, or upload the whole folder to GitHub Pages.

Included:
- Mobile-first premium storefront
- Product cards using the uploaded product images
- Add-to-cart drawer with quantity controls
- Signature Mix Snack section
- About, Why Us and Contact sections
- Demo checkout interaction
- Placeholder contact/address clearly marked for replacement

IMPORTANT:
The phone number, address, email, prices and business claims in this demo are placeholders. Verify them with the real business before accepting live orders or publishing as official information.

GitHub Pages:
1. Create a repository.
2. Upload `index.html` and the `assets` folder.
3. Go to Settings → Pages.
4. Choose Deploy from branch → main → /(root) → Save.
